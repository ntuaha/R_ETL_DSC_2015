# Code placed in this file fill be executed every time the
# lesson is started. Any variables created here will show up in
# the user's working directory and thus be accessible to them
# throughout the lesson.
setwd(get_swirl_option("courses_dir"))
x=data.frame(c1 = c(1,1,2,3,4,5,5),c2 = c('A','B','C','D','E','F','G'))
y=data.frame(c1 = c(1,2,2,3,4,6,6),c2 = c('A','B','C','D','E','F','G'))
