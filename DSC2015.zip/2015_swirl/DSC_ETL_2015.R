#install.packages("devtools")
#devtools::install_github(c("swirldev/swirl", "swirldev/swirlify"))
library(swirlify)
setwd("~/Dropbox/Project/2015/03_DSC/2015_swirl")
new_lesson("ETL", "DSC2015")

library(swirl)
delete_progress("aha");uninstall_all_courses();install_course_directory("~/Dropbox/Project/2015/03_DSC/2015_swirl/DSC2015");swirl()
２aha
aha

zip_course("~/Dropbox/Project/2015/03_DSC/2015_swirl/DSC2015")
skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();skip();
